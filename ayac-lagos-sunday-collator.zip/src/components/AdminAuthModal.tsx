import React, { useState, useEffect } from 'react';
import { ShieldAlert, KeyRound, X, Lock, CheckCircle2 } from 'lucide-react';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  title?: string;
  description?: string;
  buttonText?: string;
}

const ADMIN_ACCESS_CODE = '091993';

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  title = 'Admin Authorization Required',
  description = 'Viewing detailed attendance records is restricted to administrators upon request. Please enter the admin access code (091993) to unlock access.',
  buttonText = 'Authorize & Unlock Records',
}) => {
  const [accessCode, setAccessCode] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [showCode, setShowCode] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setAccessCode('');
      setErrorMsg('');
      setShowCode(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessCode.trim() === ADMIN_ACCESS_CODE) {
      setErrorMsg('');
      onSuccess();
      onClose();
    } else {
      setErrorMsg('Invalid admin access code. Access denied.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-rose-600 via-rose-700 to-amber-700 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <ShieldAlert className="w-6 h-6 text-rose-200" />
            </div>
            <div>
              <h3 className="text-base font-black tracking-tight">{title}</h3>
              <p className="text-xs text-rose-100 font-medium">Secured Operation</p>
            </div>
          </div>
          <button
            id="btn-close-admin-modal"
            onClick={onClose}
            className="p-1 rounded-lg text-rose-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <p className="text-xs text-slate-600 dark:text-slate-300 font-semibold leading-relaxed">
            {description}
          </p>

          {errorMsg && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center space-x-2 text-rose-700 dark:text-rose-300 text-xs font-bold animate-shake">
              <Lock className="w-4 h-4 flex-shrink-0 text-rose-500" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label
              id="lbl-admin-access-code"
              htmlFor="input-admin-access-code"
              className="block text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider mb-2"
            >
              Enter Admin Access Code <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                <KeyRound className="w-4 h-4 text-slate-400" />
              </div>
              <input
                id="input-admin-access-code"
                type={showCode ? 'text' : 'password'}
                maxLength={10}
                value={accessCode}
                onChange={(e) => {
                  setAccessCode(e.target.value);
                  if (errorMsg) setErrorMsg('');
                }}
                placeholder="••••••"
                className="w-full pl-10 pr-20 py-2.5 bg-slate-50 dark:bg-slate-950 border-2 border-slate-300 dark:border-slate-700 rounded-xl text-sm font-black tracking-widest text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500 focus:border-rose-500 outline-none"
                autoFocus
                required
              />
              <button
                type="button"
                onClick={() => setShowCode(!showCode)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-[10px] font-extrabold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                {showCode ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end space-x-3">
            <button
              type="button"
              id="btn-cancel-admin-auth"
              onClick={onClose}
              className="px-4 py-2 text-xs font-extrabold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-submit-admin-auth"
              className="px-5 py-2 text-xs font-black text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-xl shadow-md transition-colors flex items-center space-x-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{buttonText}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
